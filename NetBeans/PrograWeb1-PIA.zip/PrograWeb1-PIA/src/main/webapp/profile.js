
//Modal2
const btnAbrirModal5 = document.querySelector("#btn-abrir-modal5");
const btnCerrarModal5 = document.querySelector("#btn-cerrar-modal5");
const modal5 = document.querySelector("#modal5");

btnAbrirModal5.addEventListener("click",()=>{
    modal5.showModal();
})

btnCerrarModal5.addEventListener("click",()=>{
    modal5.close();
})


//Modal 3
const btnAbrirModal6 = document.querySelector("#btn-abrir-modal6");
const btnCerrarModal6 = document.querySelector("#btn-cerrar-modal6");
const modal6 = document.querySelector("#modal6");

btnAbrirModal6.addEventListener("click",()=>{
    modal6.showModal();
})

btnCerrarModal6.addEventListener("click",()=>{
    modal6.close();
})
